霓虹飄移 GP - 網站發布檔案

1. 將 index.html 上傳到 GitHub repository 的根目錄。
2. GitHub repository -> Settings -> Pages。
3. 在 Build and deployment 選 Deploy from a branch。
4. Branch 選 main，資料夾選 /(root)，按 Save。
5. 等待發布完成，GitHub Pages 會提供可分享的網址。

注意：遊戲使用外部 CDN 載入 Three.js、Tailwind CSS 和 Google Fonts，遊玩時需要網路連線。
最佳成績使用瀏覽器 localStorage 儲存，通常只會保存在玩家自己的裝置／瀏覽器。
